#!/bin/sh
#
# Copyright 2016, Total Validator. All rights reserved.
# Use is subject to the terms of the license.
#

#
# Change this line to point to your browser
# ensure you keep the $* part at the end though!
#
/usr/bin/firefox $*
